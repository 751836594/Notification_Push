
extern zend_class_entry *phalcon_image_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Image_Exception);

