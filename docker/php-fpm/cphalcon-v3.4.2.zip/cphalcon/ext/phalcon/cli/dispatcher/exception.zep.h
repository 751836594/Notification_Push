
extern zend_class_entry *phalcon_cli_dispatcher_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Cli_Dispatcher_Exception);

